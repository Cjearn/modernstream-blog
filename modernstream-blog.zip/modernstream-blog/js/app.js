
/* ================================================================
   ModernStream Blog — app.js
   SPA Router: hash-based navigation
================================================================ */

// ── Theme System ─────────────────────────────────────────────────
const themeToggle = () => {
  const root = document.documentElement;
  const current = root.getAttribute('data-theme');
  const next = current === 'dark' ? 'light' : 'dark';
  root.setAttribute('data-theme', next);
  localStorage.setItem('ms-theme', next);
  updateThemeIcon(next);
};

function updateThemeIcon(theme) {
  const btn = document.getElementById('theme-btn');
  if (btn) btn.innerHTML = theme === 'dark' ? '☀️' : '🌙';
}

function initTheme() {
  const saved = localStorage.getItem('ms-theme') || 'light';
  document.documentElement.setAttribute('data-theme', saved);
  updateThemeIcon(saved);
}

// ── Sticky header ─────────────────────────────────────────────────
function initHeader() {
  const hdr = document.getElementById('site-header');
  window.addEventListener('scroll', () => {
    hdr.classList.toggle('scrolled', window.scrollY > 30);
    // back to top
    const btn = document.getElementById('back-top');
    if (btn) btn.classList.toggle('visible', window.scrollY > 400);
  }, { passive: true });
}

// ── Mobile menu ───────────────────────────────────────────────────
function initMobileMenu() {
  const toggle = document.getElementById('menu-toggle');
  const nav = document.getElementById('main-nav');
  if (toggle && nav) {
    toggle.addEventListener('click', () => nav.classList.toggle('open'));
  }
}

// ── Search overlay ────────────────────────────────────────────────
function initSearch() {
  const overlay = document.getElementById('search-overlay');
  const openBtn = document.getElementById('search-btn');
  const closeBtn = document.getElementById('search-close');
  const input = document.getElementById('search-input');
  const results = document.getElementById('search-results');

  if (!overlay) return;

  openBtn.addEventListener('click', () => {
    overlay.classList.add('open');
    setTimeout(() => input.focus(), 100);
  });
  closeBtn.addEventListener('click', () => overlay.classList.remove('open'));
  overlay.addEventListener('click', e => { if (e.target === overlay) overlay.classList.remove('open'); });

  input.addEventListener('input', () => {
    const q = input.value.trim();
    if (!q) { results.innerHTML = ''; return; }
    const found = searchPosts(q);
    results.innerHTML = found.length
      ? found.map(p => `<a href="#post/${p.slug}" onclick="document.getElementById('search-overlay').classList.remove('open')" style="display:block;padding:10px 0;border-bottom:1px solid var(--border);color:var(--text);font-weight:600">${p.title} <span style="color:var(--text2);font-size:.8rem;font-weight:400">${p.category}</span></a>`).join('')
      : `<p style="color:var(--text2);font-size:.88rem;padding:10px 0">No results for "${q}"</p>`;
  });
}

// ── Scroll reveal ─────────────────────────────────────────────────
function initReveal() {
  const obs = new IntersectionObserver(entries => {
    entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('visible'); obs.unobserve(e.target); } });
  }, { threshold: 0.08 });
  document.querySelectorAll('.reveal').forEach(el => obs.observe(el));
}

// ── Reading progress ──────────────────────────────────────────────
function initReadingProgress() {
  const bar = document.getElementById('reading-progress');
  if (!bar) return;
  window.addEventListener('scroll', () => {
    const total = document.body.scrollHeight - window.innerHeight;
    bar.style.width = total > 0 ? (window.scrollY / total * 100) + '%' : '0%';
  }, { passive: true });
}

// ── Thumb SVG generator ───────────────────────────────────────────
function makeThumb(colors, emoji, extra='') {
  const [c1, c2] = colors.split(',');
  return `<div class="card-thumb thumb-chart" style="aspect-ratio:16/9;background:linear-gradient(135deg,${c1}22,${c2}11);min-height:160px;${extra}">
    <span style="font-size:2.8rem;position:relative;z-index:1">${emoji}</span>
    <svg style="position:absolute;bottom:0;left:0;right:0;opacity:.4" viewBox="0 0 300 80" preserveAspectRatio="none" height="80">
      <polyline points="0,70 40,55 80,60 120,35 160,45 200,20 240,30 300,10" fill="none" stroke="${c1}" stroke-width="2.5"/>
      <polygon points="0,80 0,70 40,55 80,60 120,35 160,45 200,20 240,30 300,10 300,80" fill="${c1}" fill-opacity=".15"/>
    </svg>
  </div>`;
}

// ── Post card ─────────────────────────────────────────────────────
function postCard(p, big = false) {
  return `<article class="post-card ${big ? 'featured-card big' : 'featured-card'} reveal" onclick="navigateTo('post/${p.slug}')">
    ${makeThumb(p.color, p.emoji)}
    <div class="card-body">
      <span class="card-cat">${p.category}</span>
      <h3 class="card-title">${p.title}</h3>
      <p class="card-excerpt">${p.excerpt}</p>
      <div class="card-meta">
        <span>${p.date}</span><span class="dot"></span>
        <span class="read-time">⏱ ${p.read_time} read</span>
      </div>
    </div>
  </article>`;
}

// ── Grid post card ────────────────────────────────────────────────
function gridCard(p) {
  return `<article class="post-card reveal" onclick="navigateTo('post/${p.slug}')">
    ${makeThumb(p.color, p.emoji)}
    <div class="card-body">
      <span class="card-cat">${p.category}</span>
      <h3 class="card-title" style="font-size:1rem">${p.title}</h3>
      <p class="card-excerpt" style="font-size:.85rem">${p.excerpt}</p>
      <div class="card-meta">
        <span>${p.date}</span><span class="dot"></span>
        <span class="read-time">⏱ ${p.read_time}</span>
      </div>
    </div>
  </article>`;
}

// ── Sidebar HTML ──────────────────────────────────────────────────
function sidebarHTML() {
  const recents = POSTS.slice(0,5).map(p => `
    <li class="recent-item" onclick="navigateTo('post/${p.slug}')" style="cursor:pointer">
      <div class="recent-thumb thumb-chart" style="background:linear-gradient(135deg,${p.color.split(',')[0]}33,${p.color.split(',')[1]}22);display:flex;align-items:center;justify-content:center;font-size:1.3rem">${p.emoji}</div>
      <div class="recent-info">
        <div class="recent-title">${p.title}</div>
        <div class="recent-date">${p.date}</div>
      </div>
    </li>`).join('');

  const cats = CATEGORIES.map(c => `
    <li class="cat-item" onclick="navigateTo('category/${c.slug}')">
      <span class="cat-name">${c.name}</span>
      <span class="cat-count">${c.count}</span>
    </li>`).join('');

  return `<aside class="sidebar">
    <div class="widget">
      <div class="widget-title">🔍 Search</div>
      <div class="widget-search">
        <input type="text" placeholder="Search articles…" id="sidebar-search" oninput="sidebarSearchHandler(this.value)">
        <button class="btn-primary" onclick="sidebarSearchHandler(document.getElementById('sidebar-search').value)">Go</button>
      </div>
      <div id="sidebar-results" style="margin-top:10px"></div>
    </div>
    <div class="widget">
      <div class="widget-title">📌 Recent Posts</div>
      <ul class="recent-list">${recents}</ul>
    </div>
    <div class="widget">
      <div class="widget-title">📂 Categories</div>
      <ul class="cat-list">${cats}</ul>
    </div>
    <div class="widget">
      <div class="widget-title">📬 Newsletter</div>
      <div class="newsletter-form">
        <p>Get the best data stories delivered to your inbox every week.</p>
        <input type="email" placeholder="your@email.com" class="form-input">
        <button class="btn-primary" onclick="alert('Thanks for subscribing! 🎉')">Subscribe →</button>
      </div>
    </div>
  </aside>`;
}

function sidebarSearchHandler(q) {
  const box = document.getElementById('sidebar-results');
  if (!box) return;
  if (!q.trim()) { box.innerHTML = ''; return; }
  const found = searchPosts(q);
  box.innerHTML = found.length
    ? found.slice(0,4).map(p=>`<div onclick="navigateTo('post/${p.slug}')" style="padding:6px 0;cursor:pointer;font-size:.85rem;color:var(--primary);font-weight:600;border-bottom:1px solid var(--border)">${p.title}</div>`).join('')
    : `<p style="font-size:.82rem;color:var(--text2)">No results found.</p>`;
}

// ================================================================
//  PAGES
// ================================================================

// ── HOME ─────────────────────────────────────────────────────────
function renderHome() {
  const featured = getFeaturedPosts();
  const [big, ...smalls] = featured;
  const rest = POSTS.filter(p => !p.featured);

  return `
  <section class="hero">
    <div class="container">
      <div class="hero-label">✦ Featured Stories</div>
      <div class="featured-grid">
        ${postCard(big, true)}
        <div style="display:flex;flex-direction:column;gap:20px">
          ${smalls.map(p => postCard(p)).join('')}
        </div>
      </div>
    </div>
  </section>

  <section style="padding:48px 0">
    <div class="container">
      <div class="grid-2">
        <div>
          <div class="section-header">
            <span class="section-title">Latest Articles</span>
            <a href="#archive" class="see-all">All articles →</a>
          </div>
          <div class="posts-grid">
            ${rest.map(p => gridCard(p)).join('')}
          </div>
          <div class="pagination">
            <button class="page-btn active">1</button>
            <button class="page-btn">2</button>
            <button class="page-btn">3</button>
            <button class="page-btn">→</button>
          </div>
        </div>
        ${sidebarHTML()}
      </div>
    </div>
  </section>`;
}

// ── SINGLE POST ───────────────────────────────────────────────────
function renderPost(slug) {
  const p = getPost(slug);
  if (!p) return render404();

  const related = getRelatedPosts(slug, p.cat_slug);
  const relHTML = related.length
    ? `<section class="related-posts">
        <div class="section-header"><span class="section-title">Related Articles</span></div>
        <div class="posts-grid">${related.map(r => gridCard(r)).join('')}</div>
       </section>`
    : '';

  const articleBody = `
    <p>Data without narrative is just noise. But when you combine <strong>precise numbers</strong> with a compelling story, something extraordinary happens — people <em>believe</em> it, remember it, and act on it.</p>
    <h2>Why Context Is Everything</h2>
    <p>A 40% increase sounds impressive. But <em>40% increase in what, over what period, compared to what baseline?</em> Without context, numbers are meaningless. The best data storytellers obsess over framing.</p>
    <blockquote>"Numbers have an important story to tell. They rely on you to give them a clear and convincing voice." — Stephen Few</blockquote>
    <h2>The Three Pillars</h2>
    <p>Every effective data story rests on three pillars: <strong>data integrity</strong>, <strong>narrative clarity</strong>, and <strong>visual design</strong>. Remove any one and the whole structure collapses.</p>
    <ul>
      <li><strong>Data integrity</strong> — your numbers must be accurate, sourced, and reproducible</li>
      <li><strong>Narrative clarity</strong> — one central insight, not a parade of statistics</li>
      <li><strong>Visual design</strong> — aesthetics that guide the eye, not distract it</li>
    </ul>
    <h2>The Chart That Changed Everything</h2>
    <p>In 1854, John Snow mapped cholera deaths in London against water pump locations. It was arguably the first data story — and it saved thousands of lives. The data was simple. The visualization was crude by today's standards. But the narrative was surgical.</p>
    <div class="chart-embed">
      <div style="background:linear-gradient(135deg,rgba(91,108,255,.08),rgba(0,212,255,.04));padding:40px;display:flex;align-items:center;justify-content:center;min-height:200px">
        <svg viewBox="0 0 500 160" style="width:100%;max-width:500px">
          <defs><linearGradient id="g1" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stop-color="#5b6cff" stop-opacity=".5"/>
            <stop offset="100%" stop-color="#5b6cff" stop-opacity="0"/>
          </linearGradient></defs>
          <polyline points="0,140 60,120 120,100 180,75 240,85 300,50 360,60 420,30 500,20" fill="none" stroke="#5b6cff" stroke-width="3" stroke-linecap="round"/>
          <polygon points="0,160 0,140 60,120 120,100 180,75 240,85 300,50 360,60 420,30 500,20 500,160" fill="url(#g1)"/>
          <circle cx="300" cy="50" r="5" fill="#ff4d6d"/>
          <text x="308" y="46" fill="#ff4d6d" font-size="11" font-family="Inter,sans-serif">Peak insight</text>
        </svg>
      </div>
      <figcaption>Fig 1 — Engagement lifts dramatically when narrative is paired with data. Source: ModernStream Research 2026</figcaption>
    </div>
    <h2>Practical Takeaways</h2>
    <ol>
      <li>Lead with the insight, not the methodology</li>
      <li>Cut every number that doesn't serve the story</li>
      <li>Use color to highlight, not decorate</li>
      <li>Write a headline that makes the finding obvious</li>
      <li>End with a clear implication — what should the reader <em>do</em> with this?</li>
    </ol>
    <p>The gap between a forgettable report and a memorable story is rarely about the data itself. It's about the choices you make in presenting it.</p>`;

  return `
  <div id="reading-progress"></div>
  <div class="single-hero">
    <div class="container">
      <div class="breadcrumb">
        <a href="#" onclick="navigateTo('')">Home</a> ›
        <a href="#category/${p.cat_slug}" onclick="navigateTo('category/${p.cat_slug}')">${p.category}</a> ›
        <span>${p.title}</span>
      </div>
      <div style="margin-bottom:12px"><span class="tag">${p.category}</span></div>
      <h1>${p.title}</h1>
      <div class="single-meta">
        <div class="author-chip">
          <div class="author-avatar">MS</div>
          <div>
            <div class="author-name">ModernStream Team</div>
            <div style="font-size:.75rem;color:var(--text2)">${p.date}</div>
          </div>
        </div>
        <span style="color:var(--text2);font-size:.85rem">⏱ ${p.read_time} read</span>
        <span class="badge badge-primary">${p.category}</span>
      </div>
    </div>
  </div>

  <section class="article-wrap">
    <div class="container">
      <div class="grid-2">
        <div>
          ${makeThumb(p.color, p.emoji, 'aspect-ratio:16/9;border-radius:14px;margin-bottom:32px;min-height:240px')}
          <div class="article-content">${articleBody}</div>

          <div class="share-bar reveal">
            <span class="share-label">Share this article:</span>
            <button class="share-btn twitter" onclick="sharePost('twitter','${p.title}')">🐦 Twitter</button>
            <button class="share-btn linkedin" onclick="sharePost('linkedin','${p.title}')">💼 LinkedIn</button>
            <button class="share-btn" onclick="copyLink()">🔗 Copy Link</button>
          </div>

          <div class="author-box reveal">
            <div class="avatar">MS</div>
            <div>
              <h4>ModernStream Team</h4>
              <p>We write about data storytelling, visualization, and the craft of making numbers meaningful. Based on the web, obsessed with clarity.</p>
            </div>
          </div>

          ${relHTML}
          ${renderComments()}
        </div>
        ${sidebarHTML()}
      </div>
    </div>
  </section>`;
}

function sharePost(platform, title) {
  const url = window.location.href;
  const urls = {
    twitter: `https://twitter.com/intent/tweet?text=${encodeURIComponent(title)}&url=${encodeURIComponent(url)}`,
    linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(url)}`,
  };
  window.open(urls[platform], '_blank');
}
function copyLink() {
  navigator.clipboard.writeText(window.location.href).then(() => alert('Link copied! ✅'));
}

// ── COMMENTS ─────────────────────────────────────────────────────
function renderComments() {
  const comments = [
    {name:'Alex Morgan', date:'March 6, 2026', text:'This is exactly what I needed. The section on annotation is something I\'m going to apply to my next report immediately.', init:'AM'},
    {name:'Priya Singh', date:'March 7, 2026', text:'The John Snow example never gets old. Such a perfect case study for data narrative.', init:'PS'},
  ];
  return `
  <section class="comments-section reveal">
    <h3 style="margin-bottom:24px">💬 ${comments.length} Comments</h3>
    <ul class="comment-list">
      ${comments.map(c=>`<li class="comment-item">
        <div class="comment-avatar">${c.init}</div>
        <div>
          <span class="comment-name">${c.name}</span>
          <span class="comment-date">${c.date}</span>
          <div class="comment-text">${c.text}</div>
        </div>
      </li>`).join('')}
    </ul>
    <h4 style="margin-bottom:16px">Leave a Comment</h4>
    <form class="comment-form" onsubmit="submitComment(event)">
      <div class="form-row">
        <input type="text" placeholder="Your name *" class="form-input" required>
        <input type="email" placeholder="Email *" class="form-input" required>
      </div>
      <textarea placeholder="Your comment…" class="form-input" required></textarea>
      <button type="submit" class="btn-primary" style="align-self:flex-start;padding:11px 24px">Post Comment →</button>
    </form>
  </section>`;
}
function submitComment(e) {
  e.preventDefault();
  alert('Comment submitted for moderation. Thank you! 🙌');
  e.target.reset();
}

// ── ARCHIVE ───────────────────────────────────────────────────────
function renderArchive() {
  return `
  <div class="archive-header">
    <div class="container">
      <h1>All Articles</h1>
      <p>Everything we've published on data storytelling, visualization, and the craft of making numbers meaningful.</p>
    </div>
  </div>
  <div class="container" style="padding-bottom:60px">
    <div class="grid-2">
      <div>
        <div class="posts-grid">
          ${POSTS.map(p => gridCard(p)).join('')}
        </div>
      </div>
      ${sidebarHTML()}
    </div>
  </div>`;
}

// ── CATEGORY ─────────────────────────────────────────────────────
function renderCategory(slug) {
  const cat = CATEGORIES.find(c => c.slug === slug);
  const posts = getPostsByCategory(slug);
  const name = cat ? cat.name : slug;
  return `
  <div class="archive-header">
    <div class="container">
      <div style="margin-bottom:10px"><span class="tag">${name}</span></div>
      <h1>${name}</h1>
      <p>${posts.length} article${posts.length !== 1 ? 's' : ''} in this category.</p>
    </div>
  </div>
  <div class="container" style="padding-bottom:60px">
    <div class="grid-2">
      <div>
        ${posts.length
          ? `<div class="posts-grid">${posts.map(p => gridCard(p)).join('')}</div>`
          : `<p style="color:var(--text2)">No posts in this category yet.</p>`}
      </div>
      ${sidebarHTML()}
    </div>
  </div>`;
}

// ── ABOUT ─────────────────────────────────────────────────────────
function renderAbout() {
  return `
  <div class="about-hero">
    <div class="container">
      <h1>We believe data should <span class="about-accent">tell a story.</span></h1>
      <p>ModernStream is a publication dedicated to the craft of data storytelling — helping analysts, journalists, and designers communicate insights that actually land.</p>
    </div>
  </div>
  <section style="padding:60px 0">
    <div class="container">
      <div class="section-header"><span class="section-title">Our Mission</span></div>
      <div style="max-width:720px;margin-bottom:48px">
        <p>Most data gets buried in spreadsheets or misrepresented in bad charts. We exist to change that. Every article we publish teaches one concrete skill you can apply the same day.</p>
        <p>We cover visualization theory, tools, real-world case studies, and the psychology of how people process numbers.</p>
      </div>
      <div class="section-header"><span class="section-title">The Team</span></div>
      <div class="team-grid">
        ${[
          {init:'AK', name:'Amir Koury', role:'Founder & Editor'},
          {init:'LM', name:'Layla Morris', role:'Data Visualization'},
          {init:'SP', name:'Sam Park', role:'Narrative Design'},
        ].map(m=>`<div class="team-card reveal">
          <div class="team-avatar">${m.init}</div>
          <h3>${m.name}</h3>
          <p>${m.role}</p>
        </div>`).join('')}
      </div>
    </div>
  </section>`;
}

// ── CONTACT ───────────────────────────────────────────────────────
function renderContact() {
  return `
  <section style="padding-top:60px">
    <div class="container">
      <h1>Get in Touch</h1>
      <p style="max-width:520px;margin-top:8px">Have a story tip, collaboration idea, or just want to say hello? We'd love to hear from you.</p>
      <div class="contact-grid">
        <div class="contact-info">
          ${[
            {icon:'📧', title:'Email', val:'hello@modernstream.blog'},
            {icon:'🐦', title:'Twitter', val:'@modernstreamblog'},
            {icon:'💼', title:'LinkedIn', val:'ModernStream Blog'},
          ].map(i=>`<div class="info-item reveal">
            <div class="info-icon">${i.icon}</div>
            <div class="info-text"><h4>${i.title}</h4><p>${i.val}</p></div>
          </div>`).join('')}
        </div>
        <form class="comment-form reveal" onsubmit="submitContact(event)">
          <input type="text" placeholder="Your name" class="form-input" required>
          <input type="email" placeholder="Email address" class="form-input" required>
          <input type="text" placeholder="Subject" class="form-input">
          <textarea placeholder="Your message…" class="form-input" style="min-height:150px" required></textarea>
          <button type="submit" class="btn-primary" style="align-self:flex-start;padding:12px 28px">Send Message →</button>
        </form>
      </div>
    </div>
  </section>`;
}
function submitContact(e) {
  e.preventDefault();
  alert('Message sent! We\'ll get back to you within 48 hours. ✉️');
  e.target.reset();
}

// ── 404 ───────────────────────────────────────────────────────────
function render404() {
  return `<div class="not-found">
    <div class="code">404</div>
    <h2>Page not found</h2>
    <p>The page you're looking for doesn't exist or has been moved.</p>
    <button class="btn-primary" onclick="navigateTo('')" style="margin-top:8px">← Back Home</button>
  </div>`;
}

// ── Search results page ───────────────────────────────────────────
function renderSearch(query) {
  const results = searchPosts(query);
  return `
  <div class="archive-header">
    <div class="container">
      <h1>Search: "${query}"</h1>
      <p>${results.length} result${results.length !== 1 ? 's' : ''} found.</p>
    </div>
  </div>
  <div class="container" style="padding-bottom:60px">
    ${results.length
      ? `<div class="posts-grid">${results.map(p => gridCard(p)).join('')}</div>`
      : `<p style="color:var(--text2);padding:40px 0">No articles match your search.</p>`}
  </div>`;
}

// ================================================================
//  ROUTER
// ================================================================
function getRoute() {
  const hash = window.location.hash.slice(1) || '';
  if (!hash) return { page: 'home' };
  if (hash === 'archive') return { page: 'archive' };
  if (hash === 'about') return { page: 'about' };
  if (hash === 'contact') return { page: 'contact' };
  if (hash.startsWith('post/')) return { page: 'post', slug: hash.slice(5) };
  if (hash.startsWith('category/')) return { page: 'category', slug: hash.slice(9) };
  if (hash.startsWith('search/')) return { page: 'search', query: decodeURIComponent(hash.slice(7)) };
  return { page: '404' };
}

function navigateTo(path) {
  window.location.hash = path ? '#' + path : '#';
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function renderPage() {
  const route = getRoute();
  const main = document.getElementById('main-content');
  if (!main) return;

  let html = '';
  if (route.page === 'home') html = renderHome();
  else if (route.page === 'post') html = renderPost(route.slug);
  else if (route.page === 'archive') html = renderArchive();
  else if (route.page === 'category') html = renderCategory(route.slug);
  else if (route.page === 'about') html = renderAbout();
  else if (route.page === 'contact') html = renderContact();
  else if (route.page === 'search') html = renderSearch(route.query);
  else html = render404();

  main.innerHTML = html;

  // update active nav
  document.querySelectorAll('nav a').forEach(a => {
    const href = a.getAttribute('href').slice(1);
    const active = (route.page === 'home' && !href) ||
                   (route.page === 'archive' && href === 'archive') ||
                   (route.page === 'about' && href === 'about') ||
                   (route.page === 'contact' && href === 'contact');
    a.classList.toggle('active', active);
  });

  // re-init reading progress for single post
  if (route.page === 'post') initReadingProgress();

  // close mobile nav
  document.getElementById('main-nav')?.classList.remove('open');

  requestAnimationFrame(() => initReveal());
}

// ── INIT ───────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  initTheme();
  initHeader();
  initMobileMenu();
  initSearch();
  renderPage();
});

window.addEventListener('hashchange', () => {
  renderPage();
  window.scrollTo({ top: 0, behavior: 'smooth' });
});
