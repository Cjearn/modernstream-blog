
const POSTS = [
  {
    "id": 1,
    "slug": "why-data-visualization-changes-minds",
    "title": "Why Data Visualization Changes Minds",
    "excerpt": "The difference between a chart people scroll past and one that reshapes beliefs is surprisingly small — here's what the research says.",
    "category": "Data Viz",
    "cat_slug": "data-viz",
    "date": "March 5, 2026",
    "read_time": "6 min",
    "featured": true,
    "big": true,
    "color": "#5b6cff,#00d4ff",
    "emoji": "📊"
  },
  {
    "id": 2,
    "slug": "narrative-arc-behind-every-great-dashboard",
    "title": "The Narrative Arc Behind Every Great Dashboard",
    "excerpt": "Great dashboards don't show everything — they tell one story.",
    "category": "Dashboards",
    "cat_slug": "dashboards",
    "date": "March 2, 2026",
    "read_time": "5 min",
    "featured": true,
    "big": false,
    "color": "#ff4d6d,#5b6cff",
    "emoji": "🗺️"
  },
  {
    "id": 3,
    "slug": "color-theory-for-data-storytellers",
    "title": "Color Theory for Data Storytellers",
    "excerpt": "Choosing the wrong palette doesn't just look bad — it actively misleads your audience.",
    "category": "Design",
    "cat_slug": "design",
    "date": "Feb 28, 2026",
    "read_time": "7 min",
    "featured": true,
    "big": false,
    "color": "#00d4ff,#5b6cff",
    "emoji": "🎨"
  },
  {
    "id": 4,
    "slug": "scrollytelling-guide-2026",
    "title": "Scrollytelling: The Complete Guide for 2026",
    "excerpt": "Scroll-driven narratives are the most powerful format on the web. Here's how to build one.",
    "category": "Scrollytelling",
    "cat_slug": "scrollytelling",
    "date": "Feb 22, 2026",
    "read_time": "10 min",
    "featured": false,
    "big": false,
    "color": "#5b6cff,#ff4d6d",
    "emoji": "📜"
  },
  {
    "id": 5,
    "slug": "data-journalism-tools-every-writer-needs",
    "title": "Data Journalism Tools Every Writer Needs",
    "excerpt": "From raw CSV to published story — the exact stack professionals use in 2026.",
    "category": "Tools",
    "cat_slug": "tools",
    "date": "Feb 18, 2026",
    "read_time": "8 min",
    "featured": false,
    "big": false,
    "color": "#00d4ff,#ff4d6d",
    "emoji": "🛠️"
  },
  {
    "id": 6,
    "slug": "how-to-write-data-driven-headlines",
    "title": "How to Write Data-Driven Headlines That Convert",
    "excerpt": "A headline with a number gets 36% more clicks. But it's more nuanced than that.",
    "category": "Copywriting",
    "cat_slug": "copywriting",
    "date": "Feb 14, 2026",
    "read_time": "5 min",
    "featured": false,
    "big": false,
    "color": "#ff4d6d,#00d4ff",
    "emoji": "✍️"
  },
  {
    "id": 7,
    "slug": "annotated-charts-secret-weapon",
    "title": "Annotated Charts: The Secret Weapon of Top Analysts",
    "excerpt": "Adding just three words to a chart can double its impact. A deep dive.",
    "category": "Data Viz",
    "cat_slug": "data-viz",
    "date": "Feb 10, 2026",
    "read_time": "6 min",
    "featured": false,
    "big": false,
    "color": "#5b6cff,#00d4ff",
    "emoji": "🔍"
  },
  {
    "id": 8,
    "slug": "interactive-vs-static-charts",
    "title": "Interactive vs Static Charts: When to Use Each",
    "excerpt": "Interactivity impresses — but static often persuades better. Here's the framework.",
    "category": "Design",
    "cat_slug": "design",
    "date": "Feb 5, 2026",
    "read_time": "7 min",
    "featured": false,
    "big": false,
    "color": "#00d4ff,#5b6cff",
    "emoji": "⚡"
  },
  {
    "id": 9,
    "slug": "misleading-charts-how-to-spot-them",
    "title": "Misleading Charts: How to Spot (and Avoid) Them",
    "excerpt": "Truncated axes, dual Y axes, cherry-picked ranges — the tricks bad actors use.",
    "category": "Data Literacy",
    "cat_slug": "data-literacy",
    "date": "Jan 30, 2026",
    "read_time": "9 min",
    "featured": false,
    "big": false,
    "color": "#ff4d6d,#5b6cff",
    "emoji": "⚠️"
  }
];
const CATEGORIES = [
  {
    "name": "Data Viz",
    "slug": "data-viz",
    "count": 2
  },
  {
    "name": "Dashboards",
    "slug": "dashboards",
    "count": 1
  },
  {
    "name": "Design",
    "slug": "design",
    "count": 2
  },
  {
    "name": "Scrollytelling",
    "slug": "scrollytelling",
    "count": 1
  },
  {
    "name": "Tools",
    "slug": "tools",
    "count": 1
  },
  {
    "name": "Copywriting",
    "slug": "copywriting",
    "count": 1
  },
  {
    "name": "Data Literacy",
    "slug": "data-literacy",
    "count": 1
  }
];

function getPost(slug) { return POSTS.find(p => p.slug === slug); }
function getPostsByCategory(slug) { return POSTS.filter(p => p.cat_slug === slug); }
function getFeaturedPosts() { return POSTS.filter(p => p.featured); }
function getRelatedPosts(currentSlug, catSlug, limit=3) {
  return POSTS.filter(p => p.slug !== currentSlug && p.cat_slug === catSlug).slice(0, limit);
}
function searchPosts(query) {
  const q = query.toLowerCase();
  return POSTS.filter(p => p.title.toLowerCase().includes(q) || p.excerpt.toLowerCase().includes(q));
}
